module cc {
    export interface IDataCtl {
        ctlSrc?: string;
    }

    export interface IDataSrcInfo {
        formID?: string;
    }
} 