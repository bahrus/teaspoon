///<reference path='../Scripts/typings/angularjs/angular.d.ts'/>
///<reference path='../Scripts/typings/jquery/jquery.d.ts'/>
///<reference path='ICookieCutter.ts'/>


module CookieCutter {

    export function configureAngular() {
        var ngInstance = angular
        .module('cc', [])
        .controller('ccCtrl', function ($scope) {
            //debugger;
        })
        .directive('ctlSrc', function () {
            var directive: ng.IDirective = {
                //#region directive def
                link: function (scope: ng.IScope, instanceElement: ng.IAugmentedJQuery, instanceAttributes: ng.IAttributes, controller: any, transclude: ng.ITranscludeFunction) {
                    var dataCtl = <cc.IDataCtl> instanceAttributes;
                    var dataSrcInfo = setProps<cc.IDataSrcInfo>(dataCtl.ctlSrc);
                    var frmID = dataSrcInfo.formID
                    if (frmID) {
                        $('#' + frmID).submit(function (event: Event) {
                            event.preventDefault();
                            $.ajax({
                                url: $(this).attr('action'),
                                type: $(this).attr('method'),
                                data: $(this).serialize() + '&ts=' + (new Date()).getUTCMilliseconds(), //TODO
                                dataType: 'json',
                                success: function (data) {
                                    debugger;
                                },
                                error: function (e) {
                                    debugger;
                                    alert('Something wrong');
                                }
                            });
                        });
                    }
                }
                //#endregion
            };
            return directive;
        });
        if (!testInputFormSupport()) {
            ngInstance.directive('form', function () {
                var directive: ng.IDirective = {
                    restrict: 'A',
                    link: function (scope: ng.IScope, instanceElement: ng.IAugmentedJQuery, instanceAttributes: ng.IAttributes, controller: any, transclude: ng.ITranscludeFunction) {
                        var frmAttribs = instanceAttributes['form'];
                    }
                };
                return directive;
            });
        }
        
    }

    export function setProps<T>(attr: string) : T {
        var returnObj = {};
        var tokens = attr.split(':');
        for (var i = 0, n = tokens.length; i < n; i++) {
            returnObj[tokens[2 * i]] = tokens[2 * i + 1];
        }
        return <T> returnObj;
    }

    var _supportsTestFormAttribute = -1;

    export function testInputFormSupport() : boolean {
        if (_supportsTestFormAttribute != -1) return _supportsTestFormAttribute != 0;
        var input = document.createElement('input'),
            form = document.createElement('form'),
            formId = 'test-input-form-reference-support';
        // Id of the remote form
        form.id = formId;
        // Add form and input to DOM
        document.body.appendChild(form);
        document.body.appendChild(input);
        // Add reference of form to input
        input.setAttribute('form', formId);
        // Check if reference exists
        var res = !(input.form == null);
        // Remove elements
        document.body.removeChild(form);
        document.body.removeChild(input);
        _supportsTestFormAttribute = res ? 1 : 0;
        return res;
    }
}

CookieCutter.configureAngular();